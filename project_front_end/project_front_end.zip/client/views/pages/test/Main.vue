<template>
    <div>
        <h1>Main.vue</h1>
    </div>
</template>

<script>

export default {
    data() {
        return {
            
        }
    },
    methods: {

    },
    watch: {

    },
    computed: {

    },
    components: {

    },
    mounted() {
        console.log('main mounted');
    }
}
</script>