import { useState } from "react"
import { addRowData } from "../firebaseAction"

function UserForm() {

  const [first, setFirst] = useState("길동")
  const [last, setLast] = useState("HONG")
  const [born, setBorn] = useState(1988)

  function onSubmitHandler(event) {
    event.preventDefault()
    // console.log(event.target.first.value)
    // console.log(event.target.last.value)
    // console.log(event.target.born.value)

    addRowData("users",{
      fisrt:event.target.first.value,
      last:event.target.last.value,
      born:event.target.born.value
    })
  }
  
  return (<>
  <h1>유저 폼</h1>
  <form onSubmit={onSubmitHandler}>
    <fieldset>
      <legend>회원 정보 입력</legend>
      <label>First</label>
      <input type="text" name="first" value={first} onChange={e=>setFirst(e.target.value)}></input><br/>
      <label>Last</label>
      <input type="text" name="last" value={last} onChange={e=>setLast(e.target.value)}></input><br/>
      <label>Bron</label>
      <input type="text" name="born" value={born} onChange={e=>setBorn(e.target.value)}></input><br/>
    </fieldset>
  </form>
  </>)

}export default UserForm