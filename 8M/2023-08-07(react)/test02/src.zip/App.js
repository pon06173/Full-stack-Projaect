import UserForm from "./components/UserForm";
import UserList from "./components/UserList";
import { addRowData } from "./firebaseAction";

function App() {

  addRowData("user",{
    first:"순신2",
    last:"이2",
    born:1425
  }) 

  return (
    <div>
      <h1>회원 정보 Firestore 예제</h1>
      <UserForm />
      <UserList />
    </div>
  );
}



export default App;
