package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoExam2JpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoExam2JpaApplication.class, args);
	}

}
