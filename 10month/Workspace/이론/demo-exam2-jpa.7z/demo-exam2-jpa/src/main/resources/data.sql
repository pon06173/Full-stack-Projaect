INSERT INTO Todo (task, completed) VALUES ('세수하고 밥먹기', false);
INSERT INTO Todo (task, completed) VALUES ('소프트웨어 과제하기', false);
INSERT INTO Todo (task, completed) VALUES ('복습하기', true);
INSERT INTO Todo (task, completed) VALUES ('예습하기', false);
INSERT INTO Todo (task, completed) VALUES ('친구와 놀기', true);