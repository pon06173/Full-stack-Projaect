package com.example.bookcafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookcafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookcafeApplication.class, args);
	}

}
